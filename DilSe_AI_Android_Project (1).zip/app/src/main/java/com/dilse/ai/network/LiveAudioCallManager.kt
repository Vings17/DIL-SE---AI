package com.dilse.ai.network

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Base64
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class LiveAudioCallManager(
    private val serverWsUrl: String = "wss://your-dilse-backend.run.app/api/live"
) {
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private var recordingJob: Job? = null
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null

    private val _callState = MutableStateFlow<String>("IDLE")
    val callState = _callState.asStateFlow()

    private val _isPriyaSpeaking = MutableStateFlow(false)
    val isPriyaSpeaking = _isPriyaSpeaking.asStateFlow()

    private val _latestSubtitle = MutableStateFlow("")
    val latestSubtitle = _latestSubtitle.asStateFlow()

    fun startCall(voice: String = "Kore", userName: String = "Sweetheart", language: String = "gu") {
        val request = Request.Builder().url(serverWsUrl).build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                _callState.value = "CONNECTED"
                
                // Initialize session
                val initMsg = JSONObject().apply {
                    put("type", "start")
                    put("voice", voice)
                    put("userName", userName)
                    put("language", language)
                }
                webSocket.send(initMsg.toString())

                // Start mic streaming
                startRecordingAndStreaming(webSocket)
                initAudioTrack()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val json = JSONObject(text)
                    val type = json.optString("type")

                    when (type) {
                        "audio" -> {
                            _isPriyaSpeaking.value = true
                            val base64Data = json.getString("audio")
                            val subtitle = json.optString("text")
                            if (subtitle.isNotEmpty()) {
                                _latestSubtitle.value = subtitle
                            }
                            playPcmAudio(base64Data)
                        }
                        "interrupted" -> {
                            _isPriyaSpeaking.value = false
                            audioTrack?.pause()
                            audioTrack?.flush()
                        }
                        "closed" -> {
                            endCall()
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                _callState.value = "ERROR: ${t.message}"
            }
        })
    }

    @SuppressLint("MissingPermission")
    private fun startRecordingAndStreaming(ws: WebSocket) {
        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            sampleRate,
            channelConfig,
            audioFormat,
            bufferSize
        )

        audioRecord?.startRecording()

        recordingJob = CoroutineScope(Dispatchers.IO).launch {
            val buffer = ByteArray(2048)
            while (isActive && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (read > 0) {
                    val base64Chunk = Base64.encodeToString(buffer, 0, read, Base64.NO_WRAP)
                    val audioMsg = JSONObject().apply {
                        put("type", "audio")
                        put("data", base64Chunk)
                    }
                    ws.send(audioMsg.toString())
                }
            }
        }
    }

    private fun initAudioTrack() {
        val sampleRate = 24000 // Gemini Live outputs 24kHz raw PCM
        val channelConfig = AudioFormat.CHANNEL_OUT_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val bufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat)

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(audioFormat)
                    .setSampleRate(sampleRate)
                    .setChannelMask(channelConfig)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()
    }

    private fun playPcmAudio(base64Data: String) {
        val bytes = Base64.decode(base64Data, Base64.DEFAULT)
        audioTrack?.write(bytes, 0, bytes.size)
    }

    fun endCall() {
        recordingJob?.cancel()
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null

        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null

        webSocket?.close(1000, "User ended call")
        webSocket = null
        _callState.value = "ENDED"
        _isPriyaSpeaking.value = false
    }
}
