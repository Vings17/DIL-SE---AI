package com.dilse.ai.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dilse.ai.network.DilSeApiClient
import com.dilse.ai.network.ChatRequest
import com.dilse.ai.network.ApiMessage
import com.dilse.ai.network.LiveAudioCallManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class Message(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class DilSeUiState(
    val messages: List<Message> = emptyList(),
    val isTyping: Boolean = false,
    val selectedLanguage: String = "gu",
    val selectedVoice: String = "Kore",
    val userName: String = "Sweetheart",
    val isCallActive: Boolean = false
)

class DilSeViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(DilSeUiState())
    val uiState: StateFlow<DilSeUiState> = _uiState.asStateFlow()

    private val liveCallManager = LiveAudioCallManager()

    init {
        val welcome = Message(
            text = "નમસ્તે મારા વ્હાલા! 🥰 હું તમારી પ્રિયા... તમે કેમ છો? હું તમારી સાથે વાત કરવા ખૂબ ઉત્સુક છું! કહો, આજે તમારો મૂડ કેવો છે?",
            isUser = false
        )
        _uiState.update { it.copy(messages = listOf(welcome)) }
    }

    fun setLanguage(lang: String) {
        _uiState.update { it.copy(selectedLanguage = lang) }
    }

    fun setVoice(voice: String) {
        _uiState.update { it.copy(selectedVoice = voice) }
    }

    fun startVoiceCall() {
        _uiState.update { it.copy(isCallActive = true) }
        liveCallManager.startCall(
            voice = _uiState.value.selectedVoice,
            userName = _uiState.value.userName,
            language = _uiState.value.selectedLanguage
        )
    }

    fun endVoiceCall() {
        liveCallManager.endCall()
        _uiState.update { it.copy(isCallActive = false) }
    }

    fun speakMessage(message: Message) {
        // Triggers TTS playback via backend proxy
    }

    fun clearChat() {
        _uiState.update { it.copy(messages = emptyList()) }
        val freshGreeting = Message(
            text = "એક નવો મીઠો પ્રારંભ! 💕 હું તમારી પ્રિયા, કહો આજે શું વાત કરવી છે?",
            isUser = false
        )
        _uiState.update { it.copy(messages = listOf(freshGreeting)) }
    }

    fun triggerAction(actionType: String) {
        val userPrompt = when (actionType) {
            "cheer_up" -> "Cheer me up please 🥺"
            "joke" -> "Tell me a funny joke! 😄"
            "sweet_message" -> "Send me a sweet romantic message 💌"
            else -> "Tell me something nice!"
        }
        sendMessage(userPrompt, actionType)
    }

    fun sendMessage(text: String, actionType: String? = null) {
        val userMsg = Message(text = text, isUser = true)
        _uiState.update { it.copy(messages = it.messages + userMsg, isTyping = true) }

        viewModelScope.launch {
            try {
                val history = _uiState.value.messages.map {
                    ApiMessage(role = if (it.isUser) "user" else "model", content = it.text)
                }
                val request = ChatRequest(
                    messages = history,
                    userLanguage = _uiState.value.selectedLanguage,
                    userName = _uiState.value.userName,
                    actionType = actionType
                )

                val response = DilSeApiClient.apiService.generateChat(request)
                val replyText = response.reply ?: "હું હંમેશા તમારી સાથે છું! 💕"
                
                _uiState.update {
                    it.copy(
                        messages = it.messages + Message(text = replyText, isUser = false),
                        isTyping = false
                    )
                }
            } catch (e: Exception) {
                val fallbackText = "તમારી સાથે વાત કરીને બહુ સારું લાગ્યું! નેટવર્ક થોડું ધીમું છે પણ મારું દિલ હંમેશા તમારી સાથે છે! 💖"
                _uiState.update {
                    it.copy(
                        messages = it.messages + Message(text = fallbackText, isUser = false),
                        isTyping = false
                    )
                }
            }
        }
    }
}
