package com.dilse.ai.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dilse.ai.viewmodel.DilSeViewModel
import com.dilse.ai.viewmodel.Message
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DilSeScreen(viewModel: DilSeViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()
    var inputText by remember { mutableStateOf("") }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFD1DC)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("💖", fontSize = 20.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                "DilSe AI (પ્રિયા)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = Color(0xFF4A154B)
                            )
                            Text(
                                if (uiState.isTyping) "Priya is typing... 💭" else "Online • Voice: ${uiState.selectedVoice}",
                                fontSize = 12.sp,
                                color = if (uiState.isTyping) Color(0xFFE91E63) else Color(0xFF4CAF50)
                            )
                        }
                    }
                },
                actions = {
                    // Call Button
                    IconButton(
                        onClick = { viewModel.startVoiceCall() },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0xFFE91E63))
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = "Live Voice Call", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(onClick = { showPrivacyDialog = true }) {
                        Icon(Icons.Default.Info, contentDescription = "Privacy", tint = Color(0xFF9C27B0))
                    }
                    IconButton(onClick = { viewModel.clearChat() }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Clear Chat", tint = Color(0xFF9C27B0))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFFFF0F5)
                )
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFFF0F5))
                    .padding(8.dp)
            ) {
                // Quick Action Chips including Voice Call
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    item {
                        ActionChip("📞 Voice Call") { viewModel.startVoiceCall() }
                    }
                    item {
                        ActionChip("🌸 Cheer me up") { viewModel.triggerAction("cheer_up") }
                    }
                    item {
                        ActionChip("😄 Tell me a joke") { viewModel.triggerAction("joke") }
                    }
                    item {
                        ActionChip("💌 Sweet message") { viewModel.triggerAction("sweet_message") }
                    }
                }

                // Input Bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("Dil se kaho... (Gujarati, Hindi, English)") },
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(24.dp)),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FloatingActionButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                viewModel.sendMessage(inputText)
                                inputText = ""
                            }
                        },
                        containerColor = Color(0xFFE91E63),
                        contentColor = Color.White,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send")
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFFFFF0F5), Color(0xFFF3E5F5))
                    )
                )
        ) {
            LanguageSelectorBar(
                currentLang = uiState.selectedLanguage,
                onSelectLang = { viewModel.setLanguage(it) }
            )

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp)
            ) {
                items(uiState.messages) { message ->
                    MessageBubble(message = message, onPlayTts = { viewModel.speakMessage(it) })
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("DilSe AI Privacy & Voice Guide 🛡️") },
            text = {
                Text(
                    "DilSe AI is an artificial intelligence girlfriend companion created with love to bring joy and emotional comfort.

" +
                    "• Natural Feminine Voice: Real-time Gemini Live audio with interruption support in Gujarati, Hindi & English.
" +
                    "• Zero Key Leaks: All Gemini AI calls run via the secure backend proxy with Firebase App Check.
" +
                    "• Transparent & Respectful: Priya is transparently an AI. Take breaks whenever you like. Priya never guilt-trips you!"
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text("Understood 💕")
                }
            }
        )
    }
}

@Composable
fun ActionChip(label: String, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        shadowElevation = 2.dp,
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF9C27B0),
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun LanguageSelectorBar(currentLang: String, onSelectLang: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalArrangement = Arrangement.Center
    ) {
        listOf(
            "gu" to "ગુજરાતી",
            "gujlish" to "Gujlish",
            "hi" to "हिंदी",
            "en" to "English"
        ).forEach { (code, title) ->
            FilterChip(
                selected = currentLang == code,
                onClick = { onSelectLang(code) },
                label = { Text(title, fontSize = 12.sp) },
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
fun MessageBubble(message: Message, onPlayTts: (Message) -> Unit) {
    val isUser = message.isUser
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFD1DC)),
                contentAlignment = Alignment.Center
            ) {
                Text("🌸", fontSize = 16.sp)
            }
            Spacer(modifier = Modifier.width(6.dp))
        }

        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            color = if (isUser) Color(0xFFE91E63) else Color.White,
            shadowElevation = 1.dp,
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.text,
                    color = if (isUser) Color.White else Color(0xFF333333),
                    fontSize = 15.sp
                )
                if (!isUser) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        IconButton(
                            onClick = { onPlayTts(message) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.VolumeUp,
                                contentDescription = "Play Voice",
                                tint = Color(0xFFE91E63),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
