# DilSe AI - Native Android Companion App with Gemini Live Voice

This folder contains the complete, production-ready Android Studio project with Jetpack Compose, Material 3, Kotlin Coroutines, and real-time Gemini Live audio streaming.

## 🚀 Step-by-Step Setup Guide

### 1. Requirements
- **Android Studio** Ladybug or newer
- **JDK 17** or JDK 21
- Android SDK Platform 35 (minimum Android 7.0 / SDK 24)
- Physical Android device or Emulator with microphone input enabled

### 2. Opening the Project
1. Open Android Studio.
2. Select **Open** and select this extracted directory.
3. Allow Gradle to sync dependencies automatically.

### 3. Voice Architecture & Security
> **CRITICAL SECURITY NOTE**: Never store the raw Gemini API key in the Android APK. Reverse engineering tools can extract keys in minutes.
> DilSe AI routes all voice and chat communication through the secure backend proxy (`server.ts`).

1. Deploy the backend to Google Cloud Run or Firebase Cloud Functions.
2. Open `app/src/main/java/com/dilse/ai/network/LiveAudioCallManager.kt` and update `serverWsUrl` to your deployed WebSocket URL (`wss://your-backend.run.app/api/live`).
3. Open `app/src/main/java/com/dilse/ai/network/DilSeApiService.kt` and update `BASE_URL`.
4. (Recommended) Configure **Firebase App Check** in your Cloud backend to ensure only genuine requests from your verified Android APK are authorized.

### 4. Running the App
- Connect your Android phone via USB with USB Debugging enabled, or launch an Android Virtual Device (AVD).
- Press the green **Run (Shift + F10)** button in Android Studio.
- Grant microphone permissions when prompted and tap **Call** to start talking with Priya!
